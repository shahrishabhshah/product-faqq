<?php

class Home extends CI_Controller{
    
    public function index(){
    	$this->load->library('session');
        echo 'Hello World';
    }	
}

/* End of file filename.php */
